#!/bin/bash
#Search for Roulette Dealer by Shift
#Simple Greeting to User
echo "Hello $USER!"#Request/Store Date Input

read -p "Please Enter the name of the Date you wish to locate [MMDD]:" date #Request/St$
read -p "Please Enter the Time you wish to locate [HH]:" time1 #sets frequentl$
read -p "Please Indicate AM or PM [A or P]:" period

workDir='/home/sysadmin/Desktop/Lucky_Duck_Investigations'
scheDir="$workDir/roulette_schedules/"

#sets result and output filenames as variables
findResult="$workDir/results.txt"
grepResult="$workDir/output"

#cleans up any contents of the result and output files from the last run
echo '' > $findResult
echo '' > $grepResult

#runs find command to find files that start with date specified by user
find $scheDir$date* >> $findResult

#sets the contents of the find result file to a variable
file=$(cat $findResult)

#iterates through each line in file and greps for time specified by user
for line in $file; do
grep -E "$time1:00:00 $period" $line >> $grepResult
done

#Nikita Alternative
#cat * ~/dealers/Dealer_Schedules_0310/$date | grep $time1
echo "-------------------------FIND RESULTS-------------------------"
cat $findResult          #Print Find Results--->Remove after Debug

echo "-------------------------GREP RESULTS-------------------------"
cat $grepResult          #Print Grep Results--->Remove after debugging
echo "date entered: $date"    #Print User Entered Date
echo "time entered: $time1:00 $period"   #Print User Entered Time

