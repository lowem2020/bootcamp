#!/bin/bash
#Search for Roulette Dealer by Time and Game
#Simple Greeting to User
echo "Hello $USER!"

#Request/Store Date Input
read -p "Please Enter the name of the Date you wish to locate [MMDD]:" date 
read -p "Please Enter the time you wish to locate [HH]:" time1
read -p "Please Indicate AM or PM [A or P]:" period
echo    "Please Choose a Game from the Following Choices:"
echo	"1 - Roulette"
echo	"2 - Poker"
echo	"3 - Blackjack"
read -p "Game#: " gamenum

#Set Game Directories
workDir='/home/sysadmin/Desktop/Lucky_Duck_Investigations'
roulDir="$workDir/roulette_schedules/"
pokDir="$workDir/poker_schedules/"
blkjDir="$workDir/blackjack_schedules/"
if [ "$gamenum" == 1 ]
	then 	gameDir=$roulDir
elif [ "$gamenum" == 2 ]
	then 	gameDir=$pokDir
elif [ "$gamenum" == 3 ]
	then	gameDir=$blkjDir
else
		gameDir=0
fi


#Find & grep $gameDir based on User Input
if [ "$gameDir" != 0 ]
	then
#sets result and output filenames as variables
	findResult="$workDir/results.txt"
	grepResult="$workDir/output"

#cleans up any contents of the result and output files from the last run
	echo '' > $findResult
	echo '' > $grepResult

#runs find command to find files that start with date specified by user
	find $gameDir$date* >> $findResult

#sets the contents of the find result file to a variable
	file=$(cat $findResult)

#iterates through each line in file and greps for time specified by user
	for line in $file; do
		grep -E "$time1:00:00 $period" $line >> $grepResult
	done

#Nikita Alternative
#cat * ~/dealers/Dealer_Schedules_0310/$date | grep $time1
#echo "-------------------------FIND RESULTS-------------------------"
#cat $findResult   	 #Print Find Results--->Remove after Debug
	if [ "$gamenum" == 1 ]
		then	echo "--------------------ROULETTE DEALER RESULTS----------------------------"
	elif [ "$gamenum" == 2 ]
		then	echo "-----------------------POKER DEALER RESULTS----------------------------"	
	elif [ "$gamenum" == 3 ]
		then	echo "-------------------BLACKJACK DEALER RESULTS----------------------------"
	fi
	cat $grepResult          #Print Grep Results--->Remove after debugging

else
	echo '----------------------------------INVALID GAME SELECTION -------------------------------'
fi
